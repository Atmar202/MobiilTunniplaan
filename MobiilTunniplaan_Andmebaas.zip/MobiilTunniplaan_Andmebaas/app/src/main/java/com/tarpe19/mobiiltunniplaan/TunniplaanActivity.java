package com.tarpe19.mobiiltunniplaan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class TunniplaanActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView aineInfo, klassiInfo;
    String selectionText;
    Spinner spinner1, spinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tunniplaan);

        aineInfo = findViewById(R.id.SubjectText);
        klassiInfo = findViewById(R.id.InfoText);

        spinner1 = findViewById(R.id.date);
        spinner1.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.DateDropdownText, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner2 = findViewById(R.id.day);
        spinner2.setOnItemSelectedListener(this);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.DayDropdownText, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        // selection valimisel võiks info refreshida automaatselt, kuid kui see ei õnnestu, siis võib lisada nupu

        Intent intent = getIntent();
        selectionText = intent.getStringExtra("STRING");

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Dünaamiliselt kirjutatud
                switch(position){
                    case 0:
                        // SQLLite data
                        // "{aeg} - {aeg}"
                        // Teemade ja klassi/Õpetaja sisestamine
                        aineInfo.setText("1. 8:30 - 10:55 Inglise keel(agiilsed tarkvaraarenduse metoodikad\n2. 11:00 - 11:45 Ajalugu ja ühiskonnaõpetus\n" +
                                "11:50 - 12:35 Söögivahetund\n4. 12:40 - 15:55 Võrgurakendused");
                        klassiInfo.setText("B228 / Margit Uiboaid\n\n\n\nB238 / Silva Kiveste\n\n\n\n\nA236 / Kristjan Kivikangur");
                        break;
                    case 1:
                        aineInfo.setText("1. 8:30 - 11:45 Agiilsed tarkvara meetmed\n11:50 - 12:35 Söögivahetund\n3. 12:40 - 15:55 Võrgurakendused\n");
                        klassiInfo.setText("236 / Kristjan Kivikangu\n\n\n 236 / Kristjan Kivikangu");
                        break;
                    case 2:
                        aineInfo.setText("1. 8:30 - 10:55 Andmebaasisüsteemi alused\n11:00 - 11:45 Söögivahetund\n3. 11:50 - 12:35 Inglise keel(agiilsed tarkvaraarenduse metoodikad\n4. 12:40 - 14:15 Ajalugu ja ühiskonnaõpetus\n5. 14:20 - 15:55 Võrgurakendused");
                        klassiInfo.setText("A116 / Ingvar Derešivski\n\n\n\nB228 / Margit Uiboaid\n\n\n\nB238 / Silva Kiveste\n\n\nA236 / Kristjan Kivikangur");
                        break;
                    case 3:
                        aineInfo.setText("1. 8:30 - 11:45 Agiilsed tarkvara meetmed\n2. 11:50 - 12:35 Rühmajuhataja tund");
                        klassiInfo.setText("A236 / Kristjan Kivikangu\nA143 Ene Kiviraijuja");
                        break;
                    case 4:
                        aineInfo.setText("1. 8:30 - 10:05 Vene keel\n2. 10:10 - 11:45 Andmebaasisüsteemi alused\n11:50 - 12:35 Söögivahetund\n4. 12:40 - 14:15 Andmebaasisüsteemi alused");
                        klassiInfo.setText("B219 / Aleksandra Pšenitšner\n\nA116 / Ingvar Derešivski\n\n\n\nA116 / Ingvar Derešivski");
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    // Viib tagasi eelmisse activitysse
    public void onBack(View view) {
        onBackPressed();
    }

    public void onNextActivity(View view) {
        Intent newActivity = new Intent(this, MuudatusedActivity.class);
        startActivity(newActivity);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}