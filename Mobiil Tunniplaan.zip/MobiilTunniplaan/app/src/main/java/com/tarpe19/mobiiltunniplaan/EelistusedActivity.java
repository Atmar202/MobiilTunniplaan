package com.tarpe19.mobiiltunniplaan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class EelistusedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eelistused);

        // Jätta viimaseks ülesandeks
        // UI Värvi muutmine peaks simple olema
    }

    public void onBack(View view) {
        onBackPressed();
    }
}