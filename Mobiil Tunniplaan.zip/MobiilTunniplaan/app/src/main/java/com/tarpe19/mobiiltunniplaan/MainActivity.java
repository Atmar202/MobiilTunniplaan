package com.tarpe19.mobiiltunniplaan;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText groupName;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        groupName = findViewById(R.id.enterGroup);
        // Umbkaudu spinneri deklareerimine
        // https://developer.android.com/guide/topics/ui/controls/spinner
        spinner = findViewById(R.id.chooseGroup);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.chooseGroup, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setPrompt("Vali rühm"); // Lisab default väärtuseks "Vali rühm"
        // Leia spinner selection ja vastavalt sellele näitada andmebaasis olevaid päringuid
        spinner.setAdapter(adapter);
    }

    public void onSearch(View view) {
        // Vaata kas groupName sisaldab andmebaasis olevat päringut (TARpe19), kui mitte siis tagastada error
        // Võib kasutada lihtsat andmebaasi nagu nt: SQL Lite (Näitab staatilisi andmeid, mis ei sobi kui on vaja salvestada palju andmeid)
        // Kokkuvõtteks on lisada ühe rühma andmed (TARpe19) ja kõik tunniplaani muudatused andmebaasi, et demonstreerida kuidas see võiks töötada
    }

    // On item selected (Spinner)
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    // When nothing is selected (Spinner), arvatavasti default value
    // Võiks kontrollida kas on lisatud groupName väärtus, kui ei ole siis võib sama hästi errori luua, sest mõlemad tingimused pole täidetud
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}