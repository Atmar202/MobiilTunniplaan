package com.tarpe19.mobiiltunniplaan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MuudatusedActivity extends AppCompatActivity {

    TextView aineInfo, klassiInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muudatused);

        aineInfo = findViewById(R.id.SubjectText);
        klassiInfo = findViewById(R.id.InfoText);
        // Salvestada järjekordeslt kaks spinnerit ja nende selectionid
        // selection valimisel võiks info refreshida automaatselt, kuid kui see ei õnnestu, siis võib lisada nupu
    }

    public void onBack(View view) {
        onBackPressed();
    }

    public void OnNextActivity(View view) {
        Intent newActivity = new Intent(this, EelistusedActivity.class);
        startActivity(newActivity);
    }
}